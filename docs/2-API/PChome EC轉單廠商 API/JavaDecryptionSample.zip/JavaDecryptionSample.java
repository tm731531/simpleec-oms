/** java -Dfile.encoding=UTF-8 JavaDecryptionSample.java **/
import java.util.Base64;

import org.apache.commons.codec.binary.Hex;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.security.MessageDigest;

public class JavaDecryptionSample
{
/**
     * AES使用CBC模式與PKCS5Padding
     */
	private static final String TRANSFORMATION = "AES/CBC/NoPadding";
	/**
     * 加密演算法使用AES
     */
    private static final String ALGORITHM = "AES";

	/*
	* 主程式
	*/
	public static void main(String args[]) throws Exception {
		/**解密**/
		System.out.println("==Decrypt==");
		System.out.println("Result->" + decrypt() + "<-" );
		System.out.println("==Decrypt==");
		/**/
	}

	/***************
	*解密
	***************/
	public static String decrypt() throws Exception {
		try {

			/*測試資料 - 解密*/
			String key	= "";
			String iv	= "";
			String data = "";
			/**/

			System.out.println("====================");
			System.out.println("MyKey:->" + key + "<-" );
			System.out.println("MyIV:->" + iv + "<-" );
			System.out.println("MyData:->" + data + "<-" );
			System.out.println("====================");

			byte[] decodedBytes = Hex.decodeHex(data);
			
			SecretKeySpec keyspec = new SecretKeySpec(key.getBytes(), ALGORITHM);
			IvParameterSpec ivspec = new IvParameterSpec(iv.getBytes());
			
			Cipher cipher = Cipher.getInstance(TRANSFORMATION);
			cipher.init(Cipher.DECRYPT_MODE, keyspec, ivspec);
			byte[] decrypted = cipher.doFinal(decodedBytes);
			
			String decodedString = new String(decrypted);

			return decodedString.trim();

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	
	}
}