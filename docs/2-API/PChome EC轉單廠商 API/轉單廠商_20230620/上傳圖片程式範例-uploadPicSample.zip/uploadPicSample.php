<?
$strUrl = 'https://ecvdr.pchome.com.tw/vdr/upload/v2/index.php/vendor/00000/file';


$arrFiles    = array() ;
$arrFilename = array('test.jpg','test1.jpg') ;

//PHP 5.4
//�@���Ǧh�i�Ϥ�
foreach($arrFilename as $key => $strFile)
{
   $arrFiles['files['.$key.']'] = '@'. realpath('img/'.$strFile).';filename='.$strFile ;
}

//�u�Ǥ@�i�Ϥ�
//$arrFiles = array('files[]' => '@'. realpath('img/test.jpg'). ';filename=test.jpg') ;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $strUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.0)' ) ;
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $arrFiles);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: multipart/form-data;")); // change Content-Type

$content = curl_exec($ch);
print_r($content);
curl_close($ch);



//PHP 5.5+
//�@���Ǧh�i�Ϥ�
foreach($arrFilename as $key => $strFile)
{
	$arrFiles['files['.$key.']'] = curl_file_create(realpath('img/'.$strFile)) ;
}

//�u�Ǥ@�i�Ϥ�
//$arrFiles = array('files[]' => curl_file_create(realpath('img/test.jpg')));

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $strUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $arrFiles);

$content = curl_exec($ch);
print_r($content);
curl_close($ch);